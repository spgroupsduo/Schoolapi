﻿using Newtonsoft.Json;
using ParentApp_School_.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Helpers;
using System.Web.Http;


namespace ParentApp_School_.Controllers
{
    public class LoginController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

      

        [HttpPost]
        [Route("PostLogin")]
        public GetLoginReturnClass PostLogin(PostLoginModel PostLoginModel)
        {
            GetLoginReturnClass loginReturnResponse = new GetLoginReturnClass();
            Response responseObj = new Response();
            List<studentDetails> listOfStudentDetails = new List<studentDetails>();

           
            var connectionString = connection;
            var query = "select *from Parent_Login where School_Id='@School_Id' and UserName='@UserName' and Password='@Password'";
            query = query.Replace("@School_Id", PostLoginModel.School_Id).Replace("@UserName", PostLoginModel.UserName).Replace("@Password", PostLoginModel.Password);
            SqlConnection Con = new SqlConnection(connectionString);
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(query, Con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string acess = (dt.Rows[0]["Acess"].ToString());

                    if (acess == "1")
                    {
                        //Response

                        var query2 = "select * from Student_Details where Parent_Id='@UserName'";
                        query2 = query2.Replace("@UserName", PostLoginModel.UserName);
                        SqlCommand cmd2 = new SqlCommand(query2, Con);
                        SqlDataReader readerdata = cmd2.ExecuteReader();

                        
                        responseObj.Response_Code = "0";
                        responseObj.Response_Message = "Authorized User";
                        loginReturnResponse.Response = responseObj;
                        while (readerdata.Read())
                        {
                            studentDetails obj2 = new studentDetails();

                            obj2.Student_Id = readerdata["Student_Id"].ToString();
                            obj2.Student_Name = readerdata["Student_Name"].ToString();
                            obj2.Roll_No = readerdata["Roll_No"].ToString();
                            obj2.Class = readerdata["Class"].ToString();
                            obj2.Section = readerdata["Section"].ToString();
                            obj2.Dob = readerdata["Dob"].ToString();
                            obj2.Age = readerdata["Age"].ToString();
                            obj2.Student_Blood_group = readerdata["Student _Bloodgroup"].ToString();
                            obj2.Parent_ID = readerdata["Parent_ID"].ToString();
                            obj2.Father_Name = readerdata["Father_Name"].ToString();
                            obj2.Father_Blood_group = readerdata["Father_Blood_group"].ToString();
                            obj2.Father_Address = readerdata["Father_Address"].ToString();
                            obj2.Father_Contact = readerdata["Father_Contact"].ToString();
                            obj2.Mother_Name = readerdata["Mother _Name"].ToString();
                            obj2.Mother_Blood_group = readerdata["Mother _Blood_group"].ToString();
                            obj2.Mother_Address = readerdata["Mother_ Address"].ToString();
                            obj2.Mother_Contact = readerdata["Mother_ Contact"].ToString();
                            obj2.Student_Address = readerdata["Student_ Address"].ToString();
                            obj2.Student_Address = readerdata["Student_ Address"].ToString();
                            obj2.Gardian_Name = readerdata["Gardian_ Name"].ToString();
                            obj2.Gardian_Address = readerdata["Gardian _ Address"].ToString();
                            obj2.Gardian_Contact = readerdata["Gardian _ Contact"].ToString();
                            obj2.Student_Profile_photo = readerdata["Student_Profile_photo"].ToString();

                            listOfStudentDetails.Add(obj2);
                            

                        }
                        loginReturnResponse.studentDetails = new List<studentDetails>();
                        loginReturnResponse.studentDetails.AddRange(listOfStudentDetails);
                    }
                    else
                    {
                        responseObj.Response_Code = "3";
                        responseObj.Response_Message = "Acess Blocked Contact School";
                        loginReturnResponse.Response = responseObj;

                    }
                }
                else
                {
                    responseObj.Response_Code = "1";
                    responseObj.Response_Message = "Invalid UserName or Password";
                    loginReturnResponse.Response = responseObj;
                }

                  
                return loginReturnResponse;

                }

            }
        
    }
}

