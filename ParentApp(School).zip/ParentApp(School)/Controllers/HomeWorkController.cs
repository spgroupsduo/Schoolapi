﻿using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{
   
    public class HomeWorkController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
              

        [HttpPost]
        [Route("PostHomeWork")]
        public GetHomeWorkReturnClass PostHomeWork(PostHomeWorkModel PostHomeWorkModel)

        {
            CultureInfo ci = new CultureInfo(CultureInfo.CurrentCulture.Name);

            ci.DateTimeFormat.ShortDatePattern = "dd'/'MM'/'yyyy";

           

            Thread.CurrentThread.CurrentCulture = ci;

            Thread.CurrentThread.CurrentUICulture = ci;

            var dt = Convert.ToDateTime(PostHomeWorkModel.Date);

            string s = dt.ToShortDateString();


            GetHomeWorkReturnClass GetHomeWorkReturnClassResponse = new GetHomeWorkReturnClass();
         
            Response responseObj = new Response();
            List<SubjectDetails> ListOfSubjects = new List<SubjectDetails>();
           
            var connectionString = connection;
            var query = "select subject,HomeWork,StartDate,EndDate from HomeWork where class='@class'and section='@Section' and date='@Date'";
            query = query.Replace("@School_Id", PostHomeWorkModel.School_Id).Replace("@class", PostHomeWorkModel.Class).Replace("@Section", PostHomeWorkModel.section).Replace("@Date", s);
            SqlConnection Con = new SqlConnection(connectionString);
            {
                Con.Open();
                SqlCommand cmd2 = new SqlCommand(query, Con);
                SqlDataReader readerdata = cmd2.ExecuteReader();
                while (readerdata.Read())
                {
                    responseObj.Response_Code = "0";
                    responseObj.Response_Message = "success";

                    SubjectDetails obj2 = new SubjectDetails();
                    obj2.Subject = readerdata["subject"].ToString();
                    obj2.HomeWork = readerdata["HomeWork"].ToString();
                    obj2.StartDate = readerdata["StartDate"].ToString();
                    obj2.EndDate = readerdata["EndDate"].ToString();
                    ListOfSubjects.Add(obj2);

                    GetHomeWorkReturnClassResponse.SubjectDetails = new List<SubjectDetails>();
                    GetHomeWorkReturnClassResponse.SubjectDetails.AddRange(ListOfSubjects);

                    GetHomeWorkReturnClassResponse.Response = responseObj;
                    GetHomeWorkReturnClassResponse.SubjectDetails = ListOfSubjects;
                }
               
                return GetHomeWorkReturnClassResponse;
            }


        }

    }

    
}
