﻿using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{
    public class LeaveApplyController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;


        // POST api/values
        [HttpPost]
        [Route("PostLeave")]
        public bool PostLogin(LeavePost LeavePost)
        {

            var query = "insert into LeaveApplySchool (School_Id,Student_Id,Class,Section,RequestDate,LeaveType,From_Date,End_Date,Reason,Sender) values('@School_Id','@Student_Id','@Class','@Section','@RequestDate','@LeaveType','@From_Date','@End_Date','@Reason','@Sender')";

            query = query.Replace("@School_Id", LeavePost.School_Id).Replace("@Student_Id", LeavePost.Student_Id).Replace("@Class", LeavePost.Class).Replace("@Section", LeavePost.section).Replace("@RequestDate", LeavePost.requestDate).Replace("@LeaveType", LeavePost.Leavetype).Replace("@From_Date", LeavePost.FromDate).Replace("@End_Date", LeavePost.ToDate).Replace("@Reason", LeavePost.Reason).Replace("@Sender", LeavePost.Sender);

            SqlConnection Con = new SqlConnection(connection);

            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                Con.Close();
                return true;
            }

            catch
            {
                Console.WriteLine("INTERNAL ERROR");
                return false;
            }
        }

    }
}
