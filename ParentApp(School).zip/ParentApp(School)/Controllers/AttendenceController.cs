﻿using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{
    public class AttendenceController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        int mn;
        [HttpPost]
        [Route("PostAttendence")]
        public GetAttendenceReturnClass PostAttendence(PostAttendenceModel PostAttendenceModel)
        {
            GetAttendenceReturnClass AttendenceReturnResponse = new GetAttendenceReturnClass();
            Response responseObj = new Response();
            List<WorkingDays> Workingday = new List<WorkingDays>();
            List<PresentDays> presentdays = new List<PresentDays>();
            List<Holidays> Holidays = new List<Holidays>();
            List<AbsentDays> AbsentDays= new List<AbsentDays>();


          
            var connectionString = connection;
            //Present_Days
            var query = "select No_of_Present_days= sum(Morning+Afternoon)/2 from Attendence where Student_Id='@Student_Id' and class='@class' and section='@Section' and Month='@Month' and year='@year' group by Student_Id";
            query = query.Replace("@School_Id", PostAttendenceModel.School_Id).Replace("@Student_Id", PostAttendenceModel.Student_Id).Replace("@class", PostAttendenceModel.Class).Replace("@Section", PostAttendenceModel.section).Replace("@Month", PostAttendenceModel.Month).Replace("@year", PostAttendenceModel.Year);
            SqlConnection Con = new SqlConnection(connectionString);
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(query, Con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count >= 1)
                {

                    responseObj.Response_Code = "0";
                    responseObj.Response_Message = "Data Sucess";
                    PresentDays obj1 = new PresentDays();
                    obj1.No_Of_Present_days = (dt.Rows[0]["No_of_Present_days"].ToString());
                    string presentday = (dt.Rows[0]["No_of_Present_days"].ToString());
                    

                    var query2 = "select No_of_Holidays= count(*) from EventCalander where Month = '@Month' and year = '@year' and Is_Holiday = '1'";
                    query2 = query2.Replace("@Month", PostAttendenceModel.Month).Replace("@year", PostAttendenceModel.Year);
                    
                    SqlCommand cmd2 = new SqlCommand(query2, Con);
                    SqlDataAdapter sda2 = new SqlDataAdapter(cmd2);
                    DataTable dt2 = new DataTable();
                    sda2.Fill(dt2);
                    if (dt2.Rows.Count >= 1)
                    {
                        Holidays obj2 = new Holidays();
                        AbsentDays obj3 = new AbsentDays();
                        WorkingDays obj4 = new WorkingDays();
                        List<AbsentDates> dates = new List<AbsentDates>();
                        List<HolidayDates> hdates = new List<HolidayDates>();
                        string holidays = (dt2.Rows[0]["No_of_Holidays"].ToString());

                        var query4 = "Select Date,Description from EventCalander where Month = '@Month' and year = '@year' and Is_Holiday='1' ";
                        query4 = query4.Replace("@Month", PostAttendenceModel.Month).Replace("@year", PostAttendenceModel.Year);
                        SqlCommand cmd4 = new SqlCommand(query4, Con);
                        SqlDataReader readerdata4 = cmd4.ExecuteReader();
                        while (readerdata4.Read())
                        {
                            HolidayDates hd = new HolidayDates();
                            hd.Holidays_Date = readerdata4["Date"].ToString(); ;
                            hd.Holidays_Description = readerdata4["Description"].ToString();
                            hdates.Add(hd);
                            obj2.HolidayDates = hdates;
                        }
                        readerdata4.Close();
                        string ye = PostAttendenceModel.Year;
                        int yea = Convert.ToInt16(ye);
                      
                        if (PostAttendenceModel.Month!=null)
                        {
                            if (PostAttendenceModel.Month == "January")
                            {
                                mn = 01;
                            }

                            if (PostAttendenceModel.Month == "February")
                            {
                                mn = 02;
                            }

                            if (PostAttendenceModel.Month == "March")
                            {
                                mn = 03;
                            }

                            if (PostAttendenceModel.Month == "April")
                            {
                                mn = 04;
                            }

                            if (PostAttendenceModel.Month == "May")
                            {
                                mn = 05;
                            }

                            if (PostAttendenceModel.Month == "June")
                            {
                                mn = 06;
                            }

                            if (PostAttendenceModel.Month == "July")
                            {
                                mn = 07;
                            }

                            if (PostAttendenceModel.Month == "August")
                            {
                                mn = 08;
                            }

                            if (PostAttendenceModel.Month == "September")
                            {
                                mn = 09;
                            }

                            if (PostAttendenceModel.Month == "October")
                            {
                                mn = 10;
                            }

                            if (PostAttendenceModel.Month == "November")
                            {
                                mn = 11;
                            }

                            if (PostAttendenceModel.Month == "December")
                            {
                                mn = 12;
                            }
                           
                            int days = DateTime.DaysInMonth(Convert.ToInt16(yea), mn);

                            obj2.No_Of_Holidays = holidays;
                            obj4.No_of_working_days = Convert.ToString(days - (Convert.ToInt16(holidays)));
                            string workingdays = Convert.ToString(days - (Convert.ToInt16(holidays)));

                            obj3.No_Of_Absent_days = Convert.ToString(Convert.ToInt16(workingdays) - Convert.ToInt16(presentday));
                            string absentdays = Convert.ToString(Convert.ToInt16(workingdays) - Convert.ToInt16(presentday));
                            if (absentdays != "0")
                            {
                                var query3 = "Select Date,Description from Attendence where Student_Id='@Student_Id' and Month = '@Month' and year = '@year' and (Morning='0' or Afternoon='0')";
                                query3 = query3.Replace("@Month", PostAttendenceModel.Month).Replace("@year", PostAttendenceModel.Year).Replace("@Student_Id", PostAttendenceModel.Student_Id);

                                SqlCommand cmd3 = new SqlCommand(query3, Con);
                                SqlDataReader readerdata = cmd3.ExecuteReader();
                                while (readerdata.Read())
                                {
                                    AbsentDates dd = new AbsentDates();
                                    dd.Absent_days_Date = readerdata["Date"].ToString();
                                    dd.Absent_days_Description = readerdata["Description"].ToString();
                                    dates.Add(dd);
                                    obj3.AbsentDates = dates;
                                }
                            }

                            presentdays.Add(GetObj1(obj1));
                            AbsentDays.Add(GetObj3(obj3));
                            Holidays.Add(GetObj2(obj2));
                            Workingday.Add(GetObj4(obj4));


                        } }
                    AttendenceReturnResponse.Response = responseObj;


                  
                    

                    AttendenceReturnResponse.AbsentDays = new List<AbsentDays>();
                    AttendenceReturnResponse.AbsentDays.AddRange(AbsentDays);

                    AttendenceReturnResponse.Holidays = new List<Holidays>();
                    AttendenceReturnResponse.Holidays.AddRange(Holidays);

                   

                    AttendenceReturnResponse.WorkingDays = new List<WorkingDays>();
                    AttendenceReturnResponse.WorkingDays.AddRange(Workingday);

                    AttendenceReturnResponse.PresentDays = new List<PresentDays>();
                    AttendenceReturnResponse.PresentDays.AddRange(presentdays);


                    AttendenceReturnResponse.AbsentDays = AbsentDays;
                    AttendenceReturnResponse.Holidays = Holidays;
                    AttendenceReturnResponse.PresentDays = presentdays;
                    AttendenceReturnResponse.WorkingDays = Workingday;

                   

                }
                else

                {
                    responseObj.Response_Code = "1";
                    responseObj.Response_Message = "No Data Found";
                    AttendenceReturnResponse.Response = responseObj;
                    
                }
            }
            return AttendenceReturnResponse;
            
        }
        

        private static WorkingDays GetObj4(WorkingDays obj4)
        {
            return obj4;
        }

        private static PresentDays GetObj1(PresentDays obj1)
        {
            return obj1;
        }

        private static Holidays GetObj2(Holidays obj2)
        {
            return obj2;
        }

        private static AbsentDays GetObj3(AbsentDays obj3)
        {
            return obj3;
        }








    }
}
