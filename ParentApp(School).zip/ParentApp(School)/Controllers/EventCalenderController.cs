﻿using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{


    public class EventCalenderController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        
        [HttpPost]
        [Route("PostMonthEvent")]
        public MonthEventReturnClass PostMonthEvent(PostEventCalender PostEventCalender)

        {
            MonthEventReturnClass MonthEventReturnResponse = new MonthEventReturnClass();

            //var obj0 = new MonthEventReturnClass();

            //  MonthEvents check = new MonthEvents();
            Response responseObj = new Response();
            List<MonthEvents> listofevents = new List<MonthEvents>();
          
            var connectionString = connection;
            var query = "select Date ,Description from EventCalander where Month = '@Month' and year = '@year'";
            query = query.Replace("@School_Id", PostEventCalender.School_Id).Replace("@Month", PostEventCalender.Month).Replace("@year", PostEventCalender.Year);
            SqlConnection Con = new SqlConnection(connectionString);
            {
                Con.Open();
                SqlCommand cmd2 = new SqlCommand(query, Con);
                SqlDataReader readerdata = cmd2.ExecuteReader();

                responseObj.Response_Code = "0";
                responseObj.Response_Message = "success";
                if(readerdata.Read())
                {
                    while (readerdata.Read())
                    {
                        MonthEvents dd = new MonthEvents();
                        dd.date = readerdata["Date"].ToString();
                        dd.description = readerdata["Description"].ToString();
                        listofevents.Add(dd);
                    }

                    MonthEventReturnResponse.MonthEvents = new List<MonthEvents>();
                    MonthEventReturnResponse.MonthEvents.AddRange(listofevents);

                    MonthEventReturnResponse.MonthEvents = listofevents;
                    MonthEventReturnResponse.Response = responseObj;
                   
                }
                else
                {
                    responseObj.Response_Code = "0";
                    responseObj.Response_Message = "No Data Found";
                    MonthEventReturnResponse.MonthEvents = null;
                    MonthEventReturnResponse.Response = responseObj;
                   
                }
                
            }

            return MonthEventReturnResponse;


        }
    }
}
