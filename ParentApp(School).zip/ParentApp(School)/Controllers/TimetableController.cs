﻿using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{
    public class TimetableController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
               
        [HttpPost]
        [Route("PostTimetable")]
        public TimeTableReturnClass PostTimetable(PostTimeTableModel PostTimeTableModel)
        {

            TimeTableReturnClass Timetableresponse = new TimeTableReturnClass();


            Response responseObj = new Response();
           
            List<TimeTable> listoftimetable = new List<TimeTable>();
            TimeTable td = new TimeTable();
            List<Monday> Lmon = new List<Monday>();
            List<Tuesday> Ltue = new List<Tuesday>();
            List<Wednesday> Lwed = new List<Wednesday>();
            List<Thursday> Lthu = new List<Thursday>();
            List<Friday> Lfri = new List<Friday>();
            List<Saturday> Lsat = new List<Saturday>();




            responseObj.Response_Code = "0";
            responseObj.Response_Message = "Sucess";

            var connectionString = connection;
            var query = "Select Period,Time,monday from Timetable where School_Id='@School_Id' and Class='@Class' and section='@section'";
            query = query.Replace("@School_Id", PostTimeTableModel.School_Id).Replace("@Class", PostTimeTableModel.Class).Replace("@section", PostTimeTableModel.Section);
            using (SqlConnection Con = new SqlConnection(connectionString))
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(query, Con);

                SqlDataReader readerdata = cmd.ExecuteReader();
                while (readerdata.Read())
                {
                    Monday Mdata = new Monday();
                    Mdata.period = readerdata["Period"].ToString();
                    Mdata.Time = readerdata["Time"].ToString();
                    Mdata.Subject = readerdata["monday"].ToString();
                    Lmon.Add(Mdata);
                }
                readerdata.Close();

                var query1 = "Select Period,Time,Tuesday from Timetable where School_Id='@School_Id' and Class='@Class' and section='@section'";
                query1 = query1.Replace("@School_Id", PostTimeTableModel.School_Id).Replace("@Class", PostTimeTableModel.Class).Replace("@section", PostTimeTableModel.Section);
                using (SqlConnection Con1 = new SqlConnection(connectionString))
                {

                    Con1.Open();
                    SqlCommand cmd2 = new SqlCommand(query1, Con1);
                    SqlDataReader readerdata2 = cmd2.ExecuteReader();
                    while (readerdata2.Read())
                    {
                        Tuesday Tdata = new Tuesday();
                        Tdata.period = readerdata2["Period"].ToString();
                        Tdata.Time = readerdata2["Time"].ToString();
                        Tdata.Subject = readerdata2["Tuesday"].ToString();
                        Ltue.Add(Tdata);
                    }

                    readerdata2.Close();

                    var query2 = "Select Period,Time,Wednesday from Timetable where School_Id='@School_Id' and Class='@Class' and section='@section'";
                    query2 = query2.Replace("@School_Id", PostTimeTableModel.School_Id).Replace("@Class", PostTimeTableModel.Class).Replace("@section", PostTimeTableModel.Section);
                    using (SqlConnection Con2 = new SqlConnection(connectionString))
                    {

                        Con2.Open();
                        SqlCommand cmd3 = new SqlCommand(query2, Con2);
                        SqlDataReader readerdata3 = cmd3.ExecuteReader();
                        while (readerdata3.Read())
                        {
                            Wednesday Tdata = new Wednesday();
                            Tdata.period = readerdata3["Period"].ToString();
                            Tdata.Time = readerdata3["Time"].ToString();
                            Tdata.Subject = readerdata3["Wednesday"].ToString();
                            Lwed.Add(Tdata);
                        }


                        readerdata3.Close();

                        var query3 = "Select Period,Time,Thursday from Timetable where School_Id='@School_Id' and Class='@Class' and section='@section'";
                        query3 = query3.Replace("@School_Id", PostTimeTableModel.School_Id).Replace("@Class", PostTimeTableModel.Class).Replace("@section", PostTimeTableModel.Section);
                        using (SqlConnection Con3 = new SqlConnection(connectionString))
                        {

                            Con3.Open();
                            SqlCommand cmd4 = new SqlCommand(query3, Con3);
                            SqlDataReader readerdata4 = cmd4.ExecuteReader();
                            while (readerdata4.Read())
                            {
                                Thursday Tdata = new Thursday();
                                Tdata.period = readerdata4["Period"].ToString();
                                Tdata.Time = readerdata4["Time"].ToString();
                                Tdata.Subject = readerdata4["Thursday"].ToString();
                                Lthu.Add(Tdata);
                            }

                            readerdata4.Close();

                            var query4 = "Select Period,Time,Friday from Timetable where School_Id='@School_Id' and Class='@Class' and section='@section'";
                            query4 = query4.Replace("@School_Id", PostTimeTableModel.School_Id).Replace("@Class", PostTimeTableModel.Class).Replace("@section", PostTimeTableModel.Section);
                            using (SqlConnection Con5 = new SqlConnection(connectionString))
                            {

                                Con5.Open();
                                SqlCommand cmd5 = new SqlCommand(query4, Con5);
                                SqlDataReader readerdata5 = cmd5.ExecuteReader();
                                while (readerdata5.Read())
                                {
                                    Friday Tdata = new Friday();
                                    Tdata.period = readerdata5["Period"].ToString();
                                    Tdata.Time = readerdata5["Time"].ToString();
                                    Tdata.Subject = readerdata5["Friday"].ToString();
                                    Lfri.Add(Tdata);
                                }

                                readerdata5.Close();

                                var query5 = "Select Period,Time,Saturday from Timetable where School_Id='@School_Id' and Class='@Class' and section='@section'";
                                query5 = query5.Replace("@School_Id", PostTimeTableModel.School_Id).Replace("@Class", PostTimeTableModel.Class).Replace("@section", PostTimeTableModel.Section);
                                using (SqlConnection Con6 = new SqlConnection(connectionString))
                                {

                                    Con6.Open();
                                    SqlCommand cmd6 = new SqlCommand(query5, Con6);
                                    SqlDataReader readerdata6 = cmd6.ExecuteReader();
                                    while (readerdata6.Read())
                                    {
                                        Saturday Tdata = new Saturday();
                                        Tdata.period = readerdata6["Period"].ToString();
                                        Tdata.Time = readerdata6["Time"].ToString();
                                        Tdata.Subject = readerdata6["Saturday"].ToString();
                                        Lsat.Add(Tdata);
                                    }

                                    td.Monday = Lmon;
                                    td.Tuesday = Ltue;
                                    td.Wednesday = Lwed;
                                    td.Thursday = Lthu;
                                    td.Friday = Lfri;
                                    td.Saturday = Lsat;

                                    listoftimetable.Add(td);
                                    Timetableresponse.Response = responseObj;
                                    Timetableresponse.TimeTable = listoftimetable;
                                   
                                }

                                return Timetableresponse;
                            }
                        }
                    }
                }
            }
            

        }

     }
}
