﻿using Newtonsoft.Json;
using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{
    public class ExamController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        
        

        [HttpPost]
        [Route("PostExam")]
        public GetExamReturnClass PostExam(PostExamModel PostExamModel)
        {
            GetExamReturnClass ExamReturnResponse = new GetExamReturnClass();
          

            List<ExamDetails> ListOfExams = new List<ExamDetails>();
            Response responseObj = new Response();

            var connectionString = connection;
            var query0 = "select subject,Date,Time,Exam_Description from Exam where class='@class'and section='@Section'";
            query0 = query0.Replace("@School_Id", PostExamModel.School_Id).Replace("@class", PostExamModel.Class).Replace("@Section", PostExamModel.section);
            SqlConnection Con = new SqlConnection(connectionString);
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(query0, Con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    var query = "select subject,Date,Time,Exam_Description from Exam where class='@class'and section='@Section'";
                    query = query.Replace("@School_Id", PostExamModel.School_Id).Replace("@class", PostExamModel.Class).Replace("@Section", PostExamModel.section);
                    
                    {
                        
                        SqlCommand cmd2 = new SqlCommand(query, Con);
                        SqlDataReader readerdata = cmd2.ExecuteReader();
                        while (readerdata.Read())
                        {
                            responseObj.Response_Code = "0";
                            responseObj.Response_Message = "Loding success";

                            ExamDetails obj2 = new ExamDetails();
                            obj2.Subject = readerdata["subject"].ToString();
                            obj2.Time = readerdata["Time"].ToString();
                            obj2.Date = readerdata["Date"].ToString();
                            obj2.ExamDescription = readerdata["Exam_Description"].ToString();
                            ListOfExams.Add(obj2);
                        }

                        ExamReturnResponse.ExamDetails = new List<ExamDetails>();
                        ExamReturnResponse.ExamDetails.AddRange(ListOfExams);


                        ExamReturnResponse.Response = responseObj;
                        ExamReturnResponse.ExamDetails = ListOfExams;

                    }
                }
                else
                {
                    responseObj.Response_Code = "1";
                    responseObj.Response_Message = "No Data Found";
                    ExamReturnResponse.Response = responseObj;
                    
                }
                return ExamReturnResponse;

            }


        }
    }
}
