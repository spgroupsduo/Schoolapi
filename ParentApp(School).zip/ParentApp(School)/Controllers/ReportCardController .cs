﻿using ParentApp_School_.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ParentApp_School_.Controllers
{
    public class ReportCardController : ApiController
    {
        string connection = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
       

        [HttpPost]
        [Route("PostReport")]
        public GetReportCardReturnClass PostReport(PostReportCardModel PostReportCardModel)
        {

            GetReportCardReturnClass ReportCardResponse = new GetReportCardReturnClass();

            Response responseObj = new Response();
            List<term> listofreports = new List<term>();
           
            var connectionString = connection;
            var query0 = "Select Term,Subjects,TotalScore,MarkScored,Result,Remarks from Report_Card where school_id='@School_Id' and student_Id='@Student_Id' and Class='@class' and section='@Section'";
            query0 = query0.Replace("@School_Id", PostReportCardModel.School_Id).Replace("@Student_Id", PostReportCardModel.Student_Id).Replace("@class", PostReportCardModel.Class).Replace("@Section", PostReportCardModel.section);
            SqlConnection Con = new SqlConnection(connectionString);
            {

                Con.Open();
                SqlCommand cmd = new SqlCommand(query0, Con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    var query = "Select Term,Subjects,TotalScore,MarkScored,Result,Remarks from Report_Card where school_id='@School_Id' and student_Id='@Student_Id' and Class='@class' and section='@Section'";
                    query = query.Replace("@School_Id", PostReportCardModel.School_Id).Replace("@Student_Id", PostReportCardModel.Student_Id).Replace("@class", PostReportCardModel.Class).Replace("@Section", PostReportCardModel.section);
                   
                    {
                        //    Con.Open();
                        SqlCommand cmd2 = new SqlCommand(query, Con);
                        SqlDataReader readerdata = cmd2.ExecuteReader();
                        while (readerdata.Read())
                        {
                            responseObj.Response_Code = "0";
                            responseObj.Response_Message = "Loading Success";

                            term obj2 = new term();
                            obj2.Term = readerdata["Term"].ToString(); ;
                            obj2.subject = readerdata["Subjects"].ToString();
                            obj2.Total = readerdata["TotalScore"].ToString();
                            obj2.MarkScored = readerdata["MarkScored"].ToString();
                            obj2.Result = readerdata["Result"].ToString();
                            obj2.Remark = readerdata["Remarks"].ToString(); ;
                            listofreports.Add(obj2);
                        }

                        ReportCardResponse.term = new List<term>();
                        ReportCardResponse.term.AddRange(listofreports);

                        ReportCardResponse.Response = responseObj;
                        ReportCardResponse.term = listofreports;
                       
                    }


                }
                else

                {
                    responseObj.Response_Code = "0";
                    responseObj.Response_Message = "No Data Found";
                    ReportCardResponse.Response = responseObj;
                    
                }
                return ReportCardResponse;
            }
        }
            


        private static List<term> GetCheck(List<term> check)
        {
            return check;
        }

        private static term GetObj2(term obj2)
        {
            return obj2;
        }
    }
}
