﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class GetAttendenceReturnClass
    {


        public Response Response { get; set; }

        public List<WorkingDays> WorkingDays { get; set; }

        public List<PresentDays> PresentDays { get; set; }

        public List<Holidays> Holidays { get; set; }

        public List<AbsentDays> AbsentDays { get; set; }

        

    }
    public class WorkingDays
    {
        public string No_of_working_days { get; set; }

        public static implicit operator List<object>(WorkingDays v)
        {
            throw new NotImplementedException();
        }
    }

    public class PresentDays
    {
        public string No_Of_Present_days { get; set; }

       

        public static implicit operator List<object>(PresentDays v)
        {
            throw new NotImplementedException();
        }
    }


    public class Holidays
    {
        public string No_Of_Holidays { get; set; }

      public List<HolidayDates> HolidayDates { get; set; }

        public static implicit operator List<object>(Holidays v)
        {
            throw new NotImplementedException();
        }
    }

    public class AbsentDays
    {
        public string No_Of_Absent_days { get; set; }

        public List<AbsentDates> AbsentDates { get; set; }

        public static implicit operator List<object>(AbsentDays v)
        {
            throw new NotImplementedException();
        }
        
    }
    public class AbsentDates
    {


        public string Absent_days_Date { get; set; }

        public string Absent_days_Description { get; set; }

    }


    public class HolidayDates
    {
        public string Holidays_Date { get; set; }

        public string Holidays_Description { get; set; }
    }
}