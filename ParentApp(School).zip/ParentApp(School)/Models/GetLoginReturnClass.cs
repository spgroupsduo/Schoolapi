﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace ParentApp_School_.Models
{
    public class GetLoginReturnClass
    {

       
        public Response Response { get; set; }

      public  List<studentDetails> studentDetails { get; set; }
    }
    
     public class studentDetails
    {
        public string Student_Id { get; set; }
        public string Student_Name { get; set; }
        public string Class { get; set; }
        public string Section { get; set; }
        public string Roll_No { get; set; }
        public string Dob { get; set; }
        public string Age { get; set; }
        public string Student_Blood_group { get; set; }
        public string Parent_ID { get; set; }
        public string Father_Name { get; set; }
        public string Father_Blood_group { get; set; }
        public string Father_Address { get; set; }
        public string Father_Contact { get; set; }
        public string Mother_Name { get; set; }
        public string Mother_Blood_group { get; set; }
        public string Mother_Address { get; set; }
        public string Mother_Contact { get; set; }
        public string Student_Address { get; set; }
        public string Gardian_Name { get; set; }
        public string Gardian_Address { get; set; }
        public string Gardian_Contact { get; set; }
        public string Student_Profile_photo { get; set; }

        public static implicit operator List<object>(studentDetails v)
        {
            throw new NotImplementedException();
        }
    }

    public class Response
    {
        public string Response_Code { get; set; }
        public string Response_Message { get; set; }
    }

}

