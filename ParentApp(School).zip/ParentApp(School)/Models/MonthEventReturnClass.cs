﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class MonthEventReturnClass
    {

        public Response Response { get; set; }


        public List<MonthEvents> MonthEvents { get; set; }
    }

    public class MonthEvents
    {
        public string date { get; set; }
        public string description { get; set; }
        
    }
}