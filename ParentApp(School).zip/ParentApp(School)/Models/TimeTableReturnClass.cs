﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class TimeTableReturnClass
    {
        public Response Response { get; set; }

        public List<TimeTable> TimeTable { get; set; }
    }

    public class TimeTable
    {

        public List<Monday> Monday { get; set; }

        public List<Tuesday> Tuesday { get; set; }

        public List<Wednesday> Wednesday { get; set; }

        public List<Thursday> Thursday { get; set; }

        public List<Friday> Friday { get; set; }

        public List<Saturday> Saturday { get; set; }

    }

    public class Monday
    {
        public string period { get; set; }
        public string Time { get; set; }
        public string Subject { get; set; }


        public static implicit operator List<object>(Monday v)
        {
            throw new NotImplementedException();
        }


    }

    public class Tuesday
    {
        public string period { get; set; }
        public string Time { get; set; }
        public string Subject { get; set; }
    }

    public class Wednesday
    {
        public string period { get; set; }
        public string Time { get; set; }
        public string Subject { get; set; }
    }

    public class Thursday
    {
        public string period { get; set; }
        public string Time { get; set; }
        public string Subject { get; set; }
    }

    public class Friday
    {
        public string period { get; set; }
        public string Time { get; set; }
        public string Subject { get; set; }
    }

    public class Saturday
    {
        public string period { get; set; }
        public string Time { get; set; }
        public string Subject { get; set; }
    }

    
}