﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class LeavePost
    {
        public string School_Id {get; set;}
        public string Student_Id {get; set;}
        public string Class {get; set;}
        public string section {get; set;}
        public string requestDate { get; set; }
        public string Leavetype { get; set; }
        public string FromDate {get; set;}
        public string ToDate {get; set;}
        public string Reason {get; set;}
        public string Sender {get; set;}
        
        
    }
}