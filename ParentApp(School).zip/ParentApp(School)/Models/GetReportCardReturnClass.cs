﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class GetReportCardReturnClass
    {
        public Response Response { get; set; }
        public List<term> term { get; set; }
    }
    
    public class term
    {
        public string Term { get; set; }

        public string subject { get; set; }

        public string Total { get; set; }

        public string MarkScored { get; set; }

        public string Result { get; set; }
        public string Remark { get; set; }


    }
}