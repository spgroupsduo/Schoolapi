﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class GetHomeWorkReturnClass
    {

        public Response Response { get; set; }

        public List<SubjectDetails> SubjectDetails { get; set; }
    }

    public class SubjectDetails
    {

        public string Subject { get; set; }

        public string HomeWork { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

              

    }

}