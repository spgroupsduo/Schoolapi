﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParentApp_School_.Models
{
    public class PostTimeTableModel
    {

        public string School_Id { get; set;}

        public string Class { get; set;}

        public string Section { get; set;}


    }
}